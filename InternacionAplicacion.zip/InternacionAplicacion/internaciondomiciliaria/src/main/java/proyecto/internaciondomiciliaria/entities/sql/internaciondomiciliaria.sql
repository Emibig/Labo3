
drop database if exists internaciondomiciliaria;
create database internaciondomiciliaria;
use internaciondomiciliaria;

create table pacientes(
	id_paciente int auto_increment primary key,
    nombre varchar(50) not null,
    nro_socio int(10) not null,
    prepaga varchar(50) not null,
    celular int (15) not null,
    calle_altura varchar(20) not null,
    piso_departamento varchar(10) not null,
    entrecalles varchar(50)not null,
    localidad varchar (50) not null
    );

create table equipos(
    id_paciente int (10),
    id_equipo int(10) primary key, 
    descripcion varchar(100) not null,
    codigo_interno INT (5) not null,
    cantidad INT(10) not null
);

create table visitas(
    id_visita INT(5) primary key, 
    id_chofer INT(10) ,
    id_paciente int(10), 
    fecha DATE not null,
    hora_inicio TIME not null, 
    hora_fin TIME not null, 
    confirmacion VARCHAR(10)not null, 
    concretado VARCHAR (10)not null
);

create table choferes(
    id_chofer INT (10) primary key, 
    vehiculo VARCHAR(30)not null,
    nombre_chofer VARCHAR (50) not null

);

ALTER TABLE `internaciondomiciliaria`.`equipos` 
ADD INDEX `pacientes_idx` (`id_paciente` ASC) ;
;
ALTER TABLE `internaciondomiciliaria`.`equipos` 
ADD CONSTRAINT `idpacientes`
  FOREIGN KEY (`id_paciente`)
  REFERENCES `internaciondomiciliaria`.`pacientes` (`id_paciente`)
  ON DELETE NO ACTION
  ON UPDATE NO ACTION;
  
   
  ALTER TABLE `internaciondomiciliaria`.`visitas` 
ADD column zona varchar(30);
ALTER TABLE `internaciondomiciliaria`.`choferes` 
ADD column zona varchar(30);
ALTER TABLE `internaciondomiciliaria`.`pacientes` 
ADD column zona varchar(30);

ALTER TABLE `internaciondomiciliaria`.`choferes` 
ADD column id_visita int(5);


ALTER TABLE `internaciondomiciliaria`.`visitas` 
ADD INDEX `depacientes_idx` (`id_paciente` ASC) ;
ALTER TABLE `internaciondomiciliaria`.`visitas` 
ADD CONSTRAINT `apacientes`
  FOREIGN KEY (`id_paciente`)
  REFERENCES `internaciondomiciliaria`.`pacientes` (`id_paciente`)
  ON DELETE NO ACTION
  ON UPDATE NO ACTION;

-- Registros de ejemplo para la tabla "pacientes"
INSERT INTO pacientes (nombre, nro_socio, prepaga, celular, calle_altura, piso_departamento, entrecalles, localidad)
VALUES
    ('Juan Pérez', 601111, 'Osde', 1555123456, 'Monroe 4400', '3A', 'Lugones y Mariano Acha', 'CABA'),
    ('María Gómez', 602222, 'Hospital Aleman', 1555987654, 'Callao 2000', '5B', 'Lugones y Mariano Acha', 'CABA'),
    ('Pedro Rodríguez', 603333, 'Swiss Medical', 1555111222, 'Avellaneda 789', '2C', 'Lugones y Mariano Acha', 'LOMAS DE ZAMORA'),
    ('Laura Sánchez', 604444, 'Omint', 1555333444, 'Sanchez de Bustamante 1001', 'PB', 'Lugones y Mariano Acha', 'LUJAN'),
    ('Carlos López', 605555, 'Osde Compras', 1555444555, 'Colombia 1340', 'GER', 'Lugones y Mariano Acha', 'TIGRE');

-- Registros de ejemplo para la tabla "equipos"
INSERT INTO equipos (id_paciente, id_equipo, descripcion, codigo_interno, cantidad)
VALUES
    (1, 1, 'Cama ortopedica con colchon hospitalario y juego de barandas', 0101, 1),
    (2, 2, 'Colchon de aire', 0201, 1),
    (3, 3, 'Bomba de infusión enteral', 1100, 1),
    (4, 4, 'Silla de ruedas', 0300, 1),
    (5, 5, 'Elevador de inodoro aluminio', 0405, 1);

-- Registros de ejemplo para la tabla "visitas"
INSERT INTO visitas (id_visita, id_chofer, id_paciente, fecha, hora_inicio, hora_fin, confirmacion, concretado, zona)
VALUES
    (1, 10001, 1, '2023-05-22', '09:30:00', '10:30:00', 'OK', 'Concretado', 'CABA'),
    (2, 10002, 2, '2023-05-22', '12:00:00', '12:30:00', 'OK', 'pendiente', 'CABA'),
    (3, 10003, 3, '2023-05-22', '13:30:00', '14:00:00', 'OK', 'Concretado', 'SUR'),
    (4, 10004, 4, '2023-05-22', '15:00:00', '15:30:00', 'OK', 'pendiente', 'OESTE'),
    (5, 10005, 5, '2023-05-22', '16:00:00', '16:30:00', 'OK', 'Concretado', 'NORTE');
    describe visitas;
    select*from visitas;

-- Registros de ejemplo para la tabla "choferes"
INSERT INTO choferes (id_chofer, vehiculo, nombre_chofer, zona, id_visita)
VALUES
    (10001, 'Fiorino ', 'Renzo U', 'CABA', 1),
    (10002, 'Trafic', 'Gabriel G', 'CABA', 2),
    (10003, 'F100', 'Gabriel G', 'SUR', 3),
    (10004, 'Ducato', 'Juan N', 'OESTE', 4),
    (10005, 'Fiorino', 'Renzo U', 'NORTE', 5);
    select*from choferes;

    INSERT INTO pacientes (nombre, nro_socio, prepaga, celular, calle_altura, piso_departamento, entrecalles, localidad)
VALUES
    ('Analia Antares', 45000606666, 'Osde', 1555121111, 'Azcuenaga 1111', 'LOCAL', 'esq Arzobispo Espinoza', 'CABA'),
    ('Bernardo Belmonte', 12360777701,'Hospital Aleman', 155512222, 'Bulnes 300', 'casa', 'esq Brown','TEMPERLEY'),
    ('Carlos Chavez',608888/1,'Swiss Medical',1545007770, 'Castro 200 - Country El Cazador', 'lote familia Chavez','-','ESCOBAR'),
    ('Diango Dero',44000000,'Omint',1551692000,'Dalma 500','casa al fondo','esquina Diego Maradona','ITUZAINGO'),
    ('Emilia Ermes', 5600000,'Airmed',1561695000, 'Ernesto Sanchez 400', 'PH','Ernesto Sabato y Voltaire','OLIVOS');

UPDATE pacientes
	SET piso_departamento = 'lote 5'
	WHERE nombre ='Carlos Chavez';
SELECT*from pacientes;
